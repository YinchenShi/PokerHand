#libraries

import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, classification_report,confusion_matrix
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn import tree
from sklearn.naive_bayes import GaussianNB
from sklearn.multiclass import OutputCodeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn import svm


#load and transform training and testing data
data_train = pd.read_csv(filepath_or_buffer="training.csv", sep=',', header=None)
data_test = pd.read_csv(filepath_or_buffer="pokerdata.csv", sep=',', header=None)

array_train = data_train.values
data_train = array_train[:,0:10]
label_train = array_train[:,10]

array_test = data_test.values
data_test = array_test[:,0:10]
label_test = array_test[:,10]

scaler = StandardScaler()
scaler.fit(data_train)

data_train = scaler.transform(data_train)
data_test = scaler.transform(data_test)

#print("training_data:",data_train)


#Apply the MLPClassifier:
acc_array = [0] * 5
for s in range (1,6):
    #Init MLPClassifier
    clf = MLPClassifier(solver='adam', alpha=1e-5,hidden_layer_sizes=(64,64),
                        activation='tanh', learning_rate_init=0.02,max_iter=2000,random_state=s)
    #Fit the Model
    result = clf.fit(data_train, label_train)
    #Predict
    prediction = clf.predict(data_test)
    #Get Accuracy
    acc = accuracy_score(label_test, prediction)
    #Store in the Array
    acc_array[s-1] = acc
    print("Execution ",s)
    print(classification_report(label_test,prediction))
    print("Accuracy using MLPClassifier and Random Seed",s,":",str(acc)) 
    #print(confusion_matrix(label_test, prediction))
    print()
print("Mean Accuracy using MLPClassifier Classifier: ",np.array(acc_array).mean())
print()


#other models to compare
#However, these are all not ANN, so I didn't write the comparison in the report.
models = [BaggingClassifier(), RandomForestClassifier(), AdaBoostClassifier(), 
          KNeighborsClassifier(),GaussianNB(), svm.SVC(kernel='linear', C=1), OutputCodeClassifier(BaggingClassifier())]

model_names = ["Bagging with DT", "Random Forest", "AdaBoost", "KNN","Naive Bayes",
               "Linear SVM","OutputCodeClassifier with Linear SVM"]


#run each model
for model,name in zip(models,model_names):
    model.fit(data_train, label_train)

    prediction = model.predict(data_test)
    #print("prediction:",prediction)
    
    acc = accuracy_score(label_test, prediction)
    
    #print the prediction
    print(classification_report(label_test,prediction))
    #print accuracy of each model
    print("Accuracy Using",name,": " + str(acc)+'\n')
    #print confusion matrix
    print(confusion_matrix(label_test, prediction))


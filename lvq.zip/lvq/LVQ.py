from random import seed
from random import randrange
from random import random
from csv import reader
from math import sqrt

def load_csv(filename): #load data
    dataset = list()
    firstline = True
    with open(filename, 'r') as file:
        csv_reader = reader(file)
        for row in csv_reader:
            if not row:
                continue
            dataset.append(row[1:]) #get rid of first row
    return dataset


def str_column_to_float(dataset, column): #transfer all the feature data to float
	for row in dataset:
		row[column] = float(row[column].strip())

    
def find_minmax(dataset):#find min max to use in normalize
	minmax = list()
	stats = [[min(column), max(column)] for column in zip(*dataset)]
	return stats


def normalize_dataset(dataset, minmax):#normalize all the data to the range 0 to 1
	for row in dataset:
		for i in range(len(row)-1):
			row[i] = (row[i] - minmax[i][0]) / (minmax[i][1] - minmax[i][0])
			

def processing_data(filename): #get final normalized dataset
    dataset = load_csv(filename)
    for i in range(len(dataset[0])-1):
        str_column_to_float(dataset, i)
    minmax = find_minmax(dataset)
    normalize_dataset(dataset, minmax)
    for row in dataset:
        row[-1] = int(row[-1])
    return dataset


def euclidean_distance(row1, row2):#calculate euclidean distance
	distance = 0.0
	for i in range(len(row1)-1):
		distance += (row1[i] - row2[i])**2
	return sqrt(distance)


def get_bmu(codebooks,test_row):#get the codebook with least distance to input vector
    distances = list()
    for codebook in codebooks:
        dist = euclidean_distance(codebook, test_row)
        distances.append((codebook, dist))
        distances.sort(key=lambda tup: tup[1])
        return distances[0][0]

# Create a random codebook vector
def random_codebook(train):
	n_records = len(train)
	n_features = len(train[0])
	codebook = [train[randrange(n_records)][i] for i in range(n_features)]
	return codebook
    
# Calculate accuracy percentage
def accuracy_metric(actual, predicted):
	correct = 0
	for i in range(len(actual)):
		if actual[i] == predicted[i]:
			correct += 1
	return correct / float(len(actual)) * 100.0

    
def predict(codebooks, test_row):
	bmu = get_bmu(codebooks, test_row)
	return bmu[-1]
    
# Train a set of codebook vectors
def train_codebooks(train, n_codebooks, lrate, epochs):
    
	codebooks = [random_codebook(train) for i in range(n_codebooks)]
	#print(codebooks)
	for epoch in range(epochs):
		rate = lrate * (1.0-(epoch/float(epochs)))
		for row in train:
			bmu = get_bmu(codebooks, row)
			for i in range(len(row)-1):
				error = row[i] - bmu[i]
				if bmu[-1] == row[-1]:
					bmu[i] += rate * error
				else:
					bmu[i] -= rate * error
	return codebooks
    
def learning_vector_quantization(train, test, n_codebooks, lrate, epochs):
	codebooks = train_codebooks(train, n_codebooks, lrate, epochs)
	predictions = list()
	for row in test:
		output = predict(codebooks, row)
		predictions.append(output)
	return(predictions)


learn_rate = 0.1
n_epochs = 500
n_codebooks = 20
seed(1) 
filename1 = 'training.csv'
filename2 = 'pokerdata.csv'
train_set = processing_data(filename1)
test_set = processing_data(filename2)
#print(train_set[:5])
predicted = learning_vector_quantization(train_set,test_set,n_codebooks,learn_rate,n_epochs)
actual = [row[-1] for row in test_set]
accuracy = accuracy_metric(actual, predicted)
#print(predicted[:30])
#print(actual[:30])
print(accuracy)




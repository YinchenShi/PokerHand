clear;
clc;
%%Training using raw data

%load the train data from csv file
trainData = csvread('Poker Hand.csv');
%load the test data from csv file
testData = csvread('pokertest.csv');

AnsArray = trainData(:, end);
%crate 
One = ones(25010,1);
%rearrange the data from 1-10
AnsArray = full(ind2vec((AnsArray+One)', 10));
% Extract training and testing answers;
%Clear the last answer column at the end of the training dataset 
testAns = testData(:,end);
One = ones(830,1);
testAns = full(ind2vec((testAns+One)', 10));

trainData(:, end) = [];%Clear last answer column
testData(:, end) = [];
%Normalize the data
% Turn data matrices into cell arrays for training the customized neural
trainData = normalize(trainData,1);
testData = normalize(testData,1);
% backpropagation network 
hiddenLayerSize = 250;
%The number of hidden layers: 250

net = patternnet(hiddenLayerSize);
net.trainFcn = 'trainscg';
% Scaled conjugate gradient backpropagation

net.performFcn = 'mse';
% Mean squared error

net.trainParam.show = 50;
% Learning rate is chosen to be 0.01
net.trainParam.lr = 0.01;
% Momentum value is chosen to be 0.05
net.trainParam.mc = 0.5;
% Training epochs is set to 2000
net.trainParam.epochs = 2000;
% Minimum gradient is set to an extremely small value to prevent early
% termination of training
net.trainParam.min_grad = 1e-5;
%Minimum performance gradient
net.performParam.regularization = 0.2;
% Regularization value is chosen to be 0.2. The larger the value is, the
% smaller weight values will be and the training process will pursue more
% generalization
net.trainParam.showWindow

net = train(net,trainData',AnsArray);
%train the network

view(net)
y = net(testData');
perf = perform(net,y,testAns);
[c, cm, ind, per] = confusion(testAns, y);

